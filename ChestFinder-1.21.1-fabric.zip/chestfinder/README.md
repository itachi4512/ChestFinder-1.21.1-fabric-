# ChestFinder — Minecraft 1.21.1 Fabric Mod

ChestFinder is a lightweight, client-side Minecraft Fabric mod for **Minecraft 1.21.1 (Java 21)** that remembers items you have previously seen in opened chests and barrels across worlds, servers, and dimensions, and marks every matching container directly on your installed mapping mod.

ChestFinder does **not** include a standalone map or waypoint renderer. It operates exclusively alongside at least one supported map mod.

## Supported Map Mods (At Least One Required)

1. **Xaero's Minimap** (`xaerominimap` / `xaerominimapfair`)
2. **Xaero's World Map** (`xaeroworldmap`)
3. **JourneyMap** (`journeymap`, via official JourneyMap API `v2.0.0-1.21.1`)
4. **Map Atlases** (`map_atlases`)

If multiple supported map mods are installed simultaneously, ChestFinder synchronizes chest markers to all of them at once. If none are installed, ChestFinder automatically disables itself and displays a clear compatibility warning.

## Features

- **Inventory Integration:** Adds a 20×18 chest/search button (`InventoryButton`) immediately beside the vanilla Knowledge Book (Recipe Book) button in the player inventory, automatically repositioning when the Recipe Book toggles open or closed.
- **Legitimate Client-Side Scanning:** Automatically scans and updates records whenever you open normal chests, trapped chests, double chests (canonicalized to one shared record), and barrels. Shulker boxes are explicitly excluded, and unopened/inaccessible containers are never queried.
- **Persistent Per-World & Per-Server Database:** Saves JSON snapshots asynchronously and atomically under `.minecraft/config/chestfinder/worlds/` with separate files for each singleplayer world (`sp_*`), multiplayer server (`mp_*`), and Realm (`realm_*`).
- **Exact Item Search & Dimension Filtering:** Search by exact item display name (e.g., `Diamond`, `Oak Planks`) or exact registry ID (e.g., `minecraft:diamond` or `diamond`), filter by dimension, and clearly distinguish **Recently Verified** (current session, within 5 minutes) from **Previously Recorded** containers.
- **Automatic Map Marking:** Creates distinctive gold chest markers at every matching chest location, prevents duplicate waypoints using deterministic IDs, updates markers automatically if container contents change on revisit, and lets you clear active markers with one click.

## Project Architecture

```text
src/
├── main/resources/
│   └── fabric.mod.json
└── client/
    ├── java/com/chestfinder/
    │   ├── ChestFinderClient.java          # Client entrypoint & lifecycle management
    │   ├── gui/
    │   │   ├── InventoryButton.java        # Button beside the Recipe Book
    │   │   └── SearchScreen.java           # Search bar, dimension filter & results UI
    │   ├── mixin/
    │   │   └── InventoryScreenMixin.java   # Injects & syncs InventoryButton
    │   ├── scanner/
    │   │   └── StorageScanner.java         # Scans opened chests, double chests & barrels
    │   ├── storage/
    │   │   ├── ContainerType.java
    │   │   ├── ContainerRecord.java
    │   │   └── StorageDatabase.java        # Async per-world/per-server JSON persistence
    │   ├── search/
    │   │   ├── SearchResult.java
    │   │   └── SearchEngine.java           # Exact name / registry ID matching & sorting
    │   ├── waypoint/
    │   │   ├── ChestWaypoint.java
    │   │   └── WaypointManager.java        # Multi-map coordinator & deduplication
    │   └── integration/
    │       ├── MapIntegration.java
    │       ├── XaeroIntegration.java       # Xaero's Minimap & World Map integration
    │       ├── JourneyMapIntegration.java  # Official JourneyMap API v2.0.0 plugin
    │       └── MapAtlasIntegration.java    # Map Atlases integration
    └── resources/
        ├── chestfinder.client.mixins.json
        └── assets/chestfinder/
            ├── icon.png
            ├── lang/en_us.json
            └── textures/gui/
                ├── chestfinder_button.png
                ├── chestfinder_button_hover.png
                ├── chestfinder_button_disabled.png
                └── waypoint_chest.png
```

## Building from Source

### Prerequisites
- **JDK 21** (e.g., Eclipse Temurin 21 / OpenJDK 21)
- **Gradle 8.10+** (or Gradle Wrapper)
- Internet access on first build to download Minecraft 1.21.1, Yarn mappings (`1.21.1+build.3`), Fabric Loader (`0.16.10`), Fabric API (`0.116.17+1.21.1`), and JourneyMap API (`2.0.0-1.21.1`).

### Build Commands
```bash
# If using installed Gradle 8.10+:
gradle build

# Or generate the wrapper first and build:
gradle wrapper --gradle-version 8.10.2
./gradlew build
```

The compiled Fabric mod JAR will be produced at:
```text
build/libs/chestfinder-1.0.0+1.21.1.jar
```

## Installation

1. Install **Fabric Loader** for **Minecraft 1.21.1** (Java 21).
2. Place **Fabric API** (`0.116.17+1.21.1` or compatible 1.21.1 build) in your `.minecraft/mods/` folder.
3. Install at least one supported map mod for Minecraft 1.21.1 Fabric:
   - [Xaero's Minimap](https://modrinth.com/mod/xaeros-minimap) / [Xaero's World Map](https://modrinth.com/mod/xaeros-world-map)
   - [JourneyMap](https://modrinth.com/plugin/journeymap)
   - [Map Atlases](https://www.curseforge.com/minecraft/mc-mods/map-atlases)
4. Drop `chestfinder-1.0.0+1.21.1.jar` into `.minecraft/mods/` (client-side only; no server installation or OP permissions needed).
5. Launch Minecraft 1.21.1, open any chest or barrel to record its contents, then open your inventory and click the **ChestFinder** button beside the Recipe Book.
