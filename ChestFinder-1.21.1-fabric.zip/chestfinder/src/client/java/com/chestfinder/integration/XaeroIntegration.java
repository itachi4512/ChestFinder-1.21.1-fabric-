package com.chestfinder.integration;

import com.chestfinder.ChestFinderClient;
import com.chestfinder.waypoint.ChestWaypoint;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Modular integration for Xaero's Minimap and Xaero's World Map on Minecraft 1.21.1.
 *
 * Uses Xaero's live client session waypoint sets so that markers appear automatically
 * on both Xaero's Minimap and Xaero's World Map (which renders Minimap waypoints)
 * without introducing a hard compile-time dependency on Xaero JARs.
 */
public final class XaeroIntegration implements MapIntegration {

    private static final String MOD_XAERO_MINIMAP = "xaerominimap";
    private static final String MOD_XAERO_MINIMAP_FAIR = "xaerominimapfair";
    private static final String MOD_XAERO_WORLDMAP = "xaeroworldmap";

    private static final String WAYPOINT_TAG_PREFIX = "[CF] ";
    private static final String CHEST_INITIALS = "C";
    private static final int GOLD_COLOR_INDEX = 6; // Gold / chest-colored marker in Xaero palette

    private final boolean minimapLoaded;
    private final boolean worldMapLoaded;
    private final Map<String, ChestWaypoint> managedWaypoints = new ConcurrentHashMap<>();

    public XaeroIntegration() {
        FabricLoader loader = FabricLoader.getInstance();
        this.minimapLoaded = loader.isModLoaded(MOD_XAERO_MINIMAP) || loader.isModLoaded(MOD_XAERO_MINIMAP_FAIR);
        this.worldMapLoaded = loader.isModLoaded(MOD_XAERO_WORLDMAP);
    }

    @Override
    public String getDisplayName() {
        if (minimapLoaded && worldMapLoaded) {
            return "Xaero's Minimap & World Map";
        }
        return minimapLoaded ? "Xaero's Minimap" : "Xaero's World Map";
    }

    @Override
    public boolean isAvailable() {
        return minimapLoaded || worldMapLoaded;
    }

    @Override
    public void upsertWaypoint(ChestWaypoint waypoint) {
        if (!isAvailable() || waypoint == null) {
            return;
        }
        managedWaypoints.put(waypoint.id(), waypoint);

        if (minimapLoaded) {
            upsertInXaeroMinimap(waypoint);
        } else if (worldMapLoaded) {
            // World Map standalone: register coordinate highlight via WorldMapSession if accessible
            syncWithWorldMapSession(waypoint);
        }
    }

    @Override
    public void removeWaypoint(String waypointId, String dimension) {
        ChestWaypoint removed = managedWaypoints.remove(waypointId);
        if (removed == null || !minimapLoaded) {
            return;
        }
        removeFromXaeroMinimap(removed);
    }

    @Override
    public void clearAllManagedWaypoints() {
        if (minimapLoaded) {
            for (ChestWaypoint wp : managedWaypoints.values()) {
                removeFromXaeroMinimap(wp);
            }
        }
        managedWaypoints.clear();
    }

    private void upsertInXaeroMinimap(ChestWaypoint waypoint) {
        try {
            Object waypointList = resolveWaypointListForDimension(waypoint.dimension());
            if (!(waypointList instanceof List<?> rawList)) {
                return;
            }

            @SuppressWarnings("unchecked")
            List<Object> list = (List<Object>) rawList;

            // Remove any existing ChestFinder waypoint at the same coordinates to avoid duplicates
            removeMatchingEntries(list, waypoint);

            Object xaeroWaypoint = instantiateXaeroWaypoint(waypoint);
            if (xaeroWaypoint != null) {
                list.add(xaeroWaypoint);
            }
        } catch (Exception e) {
            ChestFinderClient.LOGGER.warn("[ChestFinder] Unable to sync waypoint to Xaero's Minimap: {}", e.getMessage());
        }
    }

    private void removeFromXaeroMinimap(ChestWaypoint waypoint) {
        try {
            Object waypointList = resolveWaypointListForDimension(waypoint.dimension());
            if (waypointList instanceof List<?> rawList) {
                @SuppressWarnings("unchecked")
                List<Object> list = (List<Object>) rawList;
                removeMatchingEntries(list, waypoint);
            }
        } catch (Exception e) {
            ChestFinderClient.LOGGER.debug("[ChestFinder] Failed removing Xaero waypoint: {}", e.getMessage());
        }
    }

    private void removeMatchingEntries(List<Object> list, ChestWaypoint target) {
        Iterator<Object> iterator = list.iterator();
        while (iterator.hasNext()) {
            Object entry = iterator.next();
            if (isSameChestFinderWaypoint(entry, target)) {
                iterator.remove();
            }
        }
    }

    private boolean isSameChestFinderWaypoint(Object xaeroWp, ChestWaypoint target) {
        try {
            Method getName = xaeroWp.getClass().getMethod("getName");
            Object nameObj = getName.invoke(xaeroWp);
            if (!(nameObj instanceof String name) || !name.startsWith(WAYPOINT_TAG_PREFIX)) {
                return false;
            }
            int x = (int) xaeroWp.getClass().getMethod("getX").invoke(xaeroWp);
            int y = (int) xaeroWp.getClass().getMethod("getY").invoke(xaeroWp);
            int z = (int) xaeroWp.getClass().getMethod("getZ").invoke(xaeroWp);
            return x == target.pos().getX() && y == target.pos().getY() && z == target.pos().getZ();
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Resolves the mutable List<Waypoint> from Xaero's Minimap session for the given dimension.
     * Supports both 1.21.1 BuiltInHudModules (24.x+) and XaeroMinimapSession APIs.
     */
    private Object resolveWaypointListForDimension(String dimensionId) {
        try {
            // Modern 1.21.1 Xaero's Minimap API: xaero.hud.minimap.BuiltInHudModules.MINIMAP.getCurrentSession()
            Object session = getModernMinimapSession();
            if (session != null) {
                Object worldManager = session.getClass().getMethod("getWorldManager").invoke(session);
                if (worldManager != null) {
                    Object targetWorld = resolveMinimapWorld(worldManager, dimensionId);
                    if (targetWorld != null) {
                        Object waypointSet = targetWorld.getClass().getMethod("getCurrentWaypointSet").invoke(targetWorld);
                        if (waypointSet != null) {
                            return invokeFirstAvailable(waypointSet, "getWaypoints", "getList");
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // Fall through to legacy session lookup
        }

        try {
            // Fallback for XaeroMinimapSession builds
            Class<?> sessionClass = Class.forName("xaero.common.XaeroMinimapSession");
            Object session = sessionClass.getMethod("getCurrentSession").invoke(null);
            if (session != null) {
                Object waypointsManager = sessionClass.getMethod("getWaypointsManager").invoke(session);
                if (waypointsManager != null) {
                    Object currentWorld = waypointsManager.getClass().getMethod("getCurrentWorld").invoke(waypointsManager);
                    if (currentWorld != null) {
                        Object waypointSet = currentWorld.getClass().getMethod("getCurrentSet").invoke(currentWorld);
                        if (waypointSet != null) {
                            return invokeFirstAvailable(waypointSet, "getList", "getWaypoints");
                        }
                    }
                }
            }
        } catch (Exception e) {
            ChestFinderClient.LOGGER.debug("[ChestFinder] Xaero session not ready yet: {}", e.getMessage());
        }

        return null;
    }

    private Object getModernMinimapSession() {
        try {
            Class<?> hudModules = Class.forName("xaero.hud.minimap.BuiltInHudModules");
            Field minimapField = hudModules.getField("MINIMAP");
            Object minimapModule = minimapField.get(null);
            return minimapModule.getClass().getMethod("getCurrentSession").invoke(minimapModule);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Object resolveMinimapWorld(Object worldManager, String dimensionId) throws Exception {
        // Attempt dimension-specific world lookup first
        try {
            Identifier dimIdentifier = Identifier.tryParse(dimensionId);
            if (dimIdentifier != null) {
                RegistryKey<World> dimKey = RegistryKey.of(RegistryKeys.WORLD, dimIdentifier);
                Object rootContainer = worldManager.getClass().getMethod("getCurrentRootContainer").invoke(worldManager);
                if (rootContainer != null) {
                    for (Method m : rootContainer.getClass().getMethods()) {
                        if (m.getName().equals("getSubContainer") && m.getParameterCount() == 1) {
                            Object sub = m.invoke(rootContainer, dimKey);
                            if (sub != null) {
                                Object world = invokeFirstAvailable(sub, "getCurrentWorld", "getFirstWorld");
                                if (world != null) {
                                    return world;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // Fall back to currently active world
        }
        return worldManager.getClass().getMethod("getCurrentWorld").invoke(worldManager);
    }

    private Object instantiateXaeroWaypoint(ChestWaypoint wp) throws Exception {
        Class<?> waypointClass = Class.forName("xaero.common.minimap.waypoints.Waypoint");
        String displayName = WAYPOINT_TAG_PREFIX + wp.itemDisplayName() + " x" + wp.quantity()
                + " [" + wp.containerType().getDefaultLabel() + "]";

        // Try 1.21.1 WaypointColor enum constructor first:
        // Waypoint(int x, int y, int z, String name, String initials, WaypointColor color, WaypointPurpose purpose, boolean temporary)
        try {
            Class<?> colorClass = Class.forName("xaero.hud.minimap.waypoint.WaypointColor");
            Class<?> purposeClass = Class.forName("xaero.hud.minimap.waypoint.WaypointPurpose");
            Object goldColor = Enum.valueOf(colorClass.asSubclass(Enum.class), "GOLD");
            Object normalPurpose = Enum.valueOf(purposeClass.asSubclass(Enum.class), "NORMAL");
            Constructor<?> ctor = waypointClass.getConstructor(
                    int.class, int.class, int.class,
                    String.class, String.class,
                    colorClass, purposeClass, boolean.class
            );
            return ctor.newInstance(
                    wp.pos().getX(), wp.pos().getY(), wp.pos().getZ(),
                    displayName, CHEST_INITIALS,
                    goldColor, normalPurpose, true
            );
        } catch (Exception ignored) {
            // Fall back to integer-color constructor
        }

        // Standard int-color constructor:
        // Waypoint(int x, int y, int z, String name, String initials, int color, int purpose, boolean temporary)
        Constructor<?> legacyCtor = waypointClass.getConstructor(
                int.class, int.class, int.class,
                String.class, String.class,
                int.class, int.class, boolean.class
        );
        return legacyCtor.newInstance(
                wp.pos().getX(), wp.pos().getY(), wp.pos().getZ(),
                displayName, CHEST_INITIALS,
                GOLD_COLOR_INDEX, 0, true
        );
    }

    private void syncWithWorldMapSession(ChestWaypoint waypoint) {
        try {
            Class<?> wmSessionClass = Class.forName("xaero.map.WorldMapSession");
            Object session = wmSessionClass.getMethod("getCurrentSession").invoke(null);
            if (session != null) {
                ChestFinderClient.LOGGER.debug(
                        "[ChestFinder] Xaero World Map session active; install Xaero's Minimap alongside World Map for persistent HUD/map waypoint pins ({}).",
                        waypoint.formattedTitle()
                );
            }
        } catch (Exception ignored) {
            // World Map session not yet initialized
        }
    }

    private static Object invokeFirstAvailable(Object target, String... methodNames) {
        for (String name : methodNames) {
            try {
                Method method = target.getClass().getMethod(name);
                return method.invoke(target);
            } catch (Exception ignored) {
                // Try next method name
            }
        }
        return null;
    }
}
