package com.chestfinder.integration;

import com.chestfinder.ChestFinderClient;
import com.chestfinder.waypoint.ChestWaypoint;
import journeymap.api.v2.client.IClientAPI;
import journeymap.api.v2.client.IClientPlugin;
import journeymap.api.v2.common.JourneyMapPlugin;
import journeymap.api.v2.common.waypoint.Waypoint;
import journeymap.api.v2.common.waypoint.WaypointFactory;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Official JourneyMap API v2.0.0-1.21.1 client plugin integration.
 * Registered via the "journeymap" entrypoint in fabric.mod.json so that
 * JourneyMap loads this class only when JourneyMap is installed.
 */
@JourneyMapPlugin(apiVersion = "2.0.0")
public final class JourneyMapIntegration implements IClientPlugin, MapIntegration {

    public static final String MOD_JOURNEYMAP = "journeymap";
    private static final int CHEST_MARKER_COLOR = 0xE8A317; // Warm chest gold
    private static final Identifier CHEST_ICON_TEXTURE = Identifier.of(
            ChestFinderClient.MOD_ID,
            "textures/gui/waypoint_chest.png"
    );

    private static volatile JourneyMapIntegration activePluginInstance;

    private volatile IClientAPI jmApi;
    private final Map<String, ChestWaypoint> managedWaypoints = new ConcurrentHashMap<>();

    public JourneyMapIntegration() {
        activePluginInstance = this;
    }

    /**
     * Returns the live JourneyMap plugin instance if JourneyMap initialized it,
     * or null if JourneyMap is not installed.
     */
    public static JourneyMapIntegration getActiveInstance() {
        return activePluginInstance;
    }

    public static boolean isModPresent() {
        return FabricLoader.getInstance().isModLoaded(MOD_JOURNEYMAP);
    }

    @Override
    public void initialize(IClientAPI jmClientApi) {
        this.jmApi = jmClientApi;
        activePluginInstance = this;
        ChestFinderClient.LOGGER.info("[ChestFinder] JourneyMap API v2.0.0 plugin initialized.");

        // Register with WaypointManager if ChestFinderClient is already initialized
        ChestFinderClient client = ChestFinderClient.getInstance();
        if (client != null && client.getWaypointManager() != null) {
            client.getWaypointManager().registerRuntimeIntegration(this);
        }

        // Flush any buffered waypoints
        for (ChestWaypoint wp : managedWaypoints.values()) {
            pushToJourneyMap(wp);
        }
    }

    @Override
    public String getModId() {
        return ChestFinderClient.MOD_ID;
    }

    @Override
    public String getDisplayName() {
        return "JourneyMap";
    }

    @Override
    public boolean isAvailable() {
        return isModPresent();
    }

    @Override
    public void upsertWaypoint(ChestWaypoint waypoint) {
        if (!isAvailable() || waypoint == null) {
            return;
        }
        managedWaypoints.put(waypoint.id(), waypoint);
        pushToJourneyMap(waypoint);
    }

    @Override
    public void removeWaypoint(String waypointId, String dimension) {
        ChestWaypoint removed = managedWaypoints.remove(waypointId);
        if (jmApi == null || waypointId == null) {
            return;
        }
        try {
            Waypoint existing = jmApi.getWaypoint(ChestFinderClient.MOD_ID, waypointId);
            if (existing != null) {
                jmApi.removeWaypoint(ChestFinderClient.MOD_ID, existing);
            } else if (removed != null) {
                for (Waypoint wp : jmApi.getAllWaypoints()) {
                    if (ChestFinderClient.MOD_ID.equals(wp.getModId()) && waypointId.equals(wp.getGuid())) {
                        jmApi.removeWaypoint(ChestFinderClient.MOD_ID, wp);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            ChestFinderClient.LOGGER.warn("[ChestFinder] Failed to remove JourneyMap waypoint '{}': {}", waypointId, e.getMessage());
        }
    }

    @Override
    public void clearAllManagedWaypoints() {
        if (jmApi != null) {
            try {
                for (Waypoint wp : jmApi.getAllWaypoints()) {
                    if (ChestFinderClient.MOD_ID.equals(wp.getModId())) {
                        jmApi.removeWaypoint(ChestFinderClient.MOD_ID, wp);
                    }
                }
            } catch (Exception e) {
                ChestFinderClient.LOGGER.warn("[ChestFinder] Failed to clear JourneyMap waypoints: {}", e.getMessage());
            }
        }
        managedWaypoints.clear();
    }

    private void pushToJourneyMap(ChestWaypoint wp) {
        if (jmApi == null) {
            return;
        }
        try {
            Identifier dimId = Identifier.tryParse(wp.dimension());
            if (dimId == null) {
                return;
            }
            RegistryKey<World> dimensionKey = RegistryKey.of(RegistryKeys.WORLD, dimId);

            // Remove existing waypoint with the same ID to prevent duplicates and reflect updated counts
            Waypoint existing = jmApi.getWaypoint(ChestFinderClient.MOD_ID, wp.id());
            if (existing != null) {
                jmApi.removeWaypoint(ChestFinderClient.MOD_ID, existing);
            }

            Waypoint jmWaypoint = WaypointFactory.createClientWaypoint(
                    ChestFinderClient.MOD_ID,
                    wp.pos(),
                    wp.shortTitle(),
                    dimensionKey,
                    false // Non-persistent search marker managed cleanly by ChestFinder
            );
            jmWaypoint.setGuid(wp.id());
            jmWaypoint.setColor(CHEST_MARKER_COLOR);
            jmWaypoint.setIconResourceLocation(CHEST_ICON_TEXTURE);
            jmWaypoint.setEnabled(true);

            jmApi.addWaypoint(ChestFinderClient.MOD_ID, jmWaypoint);
        } catch (NoSuchMethodError | Exception e) {
            // Fallback without custom icon setter if a minor JourneyMap 6.0.x build differs
            try {
                Identifier dimId = Identifier.tryParse(wp.dimension());
                if (dimId == null) {
                    return;
                }
                RegistryKey<World> dimensionKey = RegistryKey.of(RegistryKeys.WORLD, dimId);
                Waypoint jmWaypoint = WaypointFactory.createClientWaypoint(
                        ChestFinderClient.MOD_ID,
                        wp.pos(),
                        wp.shortTitle(),
                        dimensionKey,
                        false
                );
                jmWaypoint.setGuid(wp.id());
                jmWaypoint.setColor(CHEST_MARKER_COLOR);
                jmWaypoint.setEnabled(true);
                jmApi.addWaypoint(ChestFinderClient.MOD_ID, jmWaypoint);
            } catch (Exception inner) {
                ChestFinderClient.LOGGER.warn("[ChestFinder] Failed to create JourneyMap waypoint: {}", inner.getMessage());
            }
        }
    }
}
