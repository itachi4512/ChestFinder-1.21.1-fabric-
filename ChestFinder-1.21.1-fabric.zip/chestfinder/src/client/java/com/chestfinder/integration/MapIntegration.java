package com.chestfinder.integration;

import com.chestfinder.waypoint.ChestWaypoint;

/**
 * Modular contract implemented by every supported map-mod integration.
 */
public interface MapIntegration {

    /**
     * Human-readable name of the map mod integration (e.g. "JourneyMap").
     */
    String getDisplayName();

    /**
     * Returns true if the corresponding map mod is installed and ready for use.
     */
    boolean isAvailable();

    /**
     * Creates a new waypoint/marker or updates an existing one with the same ID.
     * Implementations must prevent duplicates.
     */
    void upsertWaypoint(ChestWaypoint waypoint);

    /**
     * Removes a previously created ChestFinder waypoint by its deterministic ID.
     */
    void removeWaypoint(String waypointId, String dimension);

    /**
     * Removes all ChestFinder-managed waypoints from this map mod.
     */
    void clearAllManagedWaypoints();
}
