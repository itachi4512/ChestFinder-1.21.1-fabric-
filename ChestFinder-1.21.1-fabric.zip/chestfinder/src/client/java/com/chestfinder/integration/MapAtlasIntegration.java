package com.chestfinder.integration;

import com.chestfinder.ChestFinderClient;
import com.chestfinder.waypoint.ChestWaypoint;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Modular integration for Map Atlases (Fabric 1.21.1).
 *
 * Hooks into Map Atlases' client-side waypoint/pin manager (and Moonlight Lib
 * map decoration markers when present) to place, update, deduplicate, and remove
 * distinctive chest markers on the player's Atlas.
 */
public final class MapAtlasIntegration implements MapIntegration {

    public static final String MOD_MAP_ATLASES = "map_atlases";
    private static final int CHEST_PIN_COLOR = 0xE8A317; // Chest gold

    private final boolean modLoaded;
    private final Map<String, ChestWaypoint> managedWaypoints = new ConcurrentHashMap<>();

    public MapAtlasIntegration() {
        this.modLoaded = FabricLoader.getInstance().isModLoaded(MOD_MAP_ATLASES);
    }

    @Override
    public String getDisplayName() {
        return "Map Atlases";
    }

    @Override
    public boolean isAvailable() {
        return modLoaded;
    }

    @Override
    public void upsertWaypoint(ChestWaypoint waypoint) {
        if (!isAvailable() || waypoint == null) {
            return;
        }
        ChestWaypoint previous = managedWaypoints.put(waypoint.id(), waypoint);
        if (previous != null) {
            removeFromAtlas(previous);
        }
        addToAtlas(waypoint);
    }

    @Override
    public void removeWaypoint(String waypointId, String dimension) {
        ChestWaypoint removed = managedWaypoints.remove(waypointId);
        if (removed != null && isAvailable()) {
            removeFromAtlas(removed);
        }
    }

    @Override
    public void clearAllManagedWaypoints() {
        if (isAvailable()) {
            for (ChestWaypoint wp : managedWaypoints.values()) {
                removeFromAtlas(wp);
            }
        }
        managedWaypoints.clear();
    }

    private void addToAtlas(ChestWaypoint waypoint) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null) {
            return;
        }

        Identifier dimId = Identifier.tryParse(waypoint.dimension());
        if (dimId == null) {
            return;
        }
        RegistryKey<World> dimKey = RegistryKey.of(RegistryKeys.WORLD, dimId);

        // Attempt 1: Map Atlases 1.21.1 ClientWaypointManager / ClientMarkers (Moonlight-backed client pins)
        if (tryAddViaMapAtlasesClientMarkers(dimKey, waypoint)) {
            return;
        }

        // Attempt 2: Moonlight Lib ClientMapMarkers API (used by Map Atlases Fabric 1.21.1 for custom pins)
        tryAddViaMoonlightClientMarkers(dimKey, waypoint);
    }

    private void removeFromAtlas(ChestWaypoint waypoint) {
        Identifier dimId = Identifier.tryParse(waypoint.dimension());
        if (dimId == null) {
            return;
        }
        RegistryKey<World> dimKey = RegistryKey.of(RegistryKeys.WORLD, dimId);

        if (tryRemoveViaMapAtlasesClientMarkers(dimKey, waypoint)) {
            return;
        }
        tryRemoveViaMoonlightClientMarkers(dimKey, waypoint);
    }

    private boolean tryAddViaMapAtlasesClientMarkers(RegistryKey<World> dimKey, ChestWaypoint wp) {
        String[] candidateClasses = {
                "pepjebs.mapatlases.client.MapAtlasesClient",
                "pepjebs.mapatlases.integration.moonlight.ClientMarkers",
                "pepjebs.mapatlases.client.markers.ClientWaypointManager"
        };
        for (String className : candidateClasses) {
            try {
                Class<?> clazz = Class.forName(className);
                for (Method m : clazz.getMethods()) {
                    String name = m.getName();
                    if ((name.equals("addMarker") || name.equals("addWaypoint") || name.equals("addClientMarker"))
                            && m.getParameterCount() >= 3) {
                        Class<?>[] params = m.getParameterTypes();
                        if (params.length == 4
                                && params[0].isAssignableFrom(RegistryKey.class)
                                && params[1].isAssignableFrom(BlockPos.class)
                                && params[2].isAssignableFrom(Text.class)
                                && params[3] == int.class) {
                            m.invoke(null, dimKey, wp.pos(), Text.literal(wp.shortTitle()), CHEST_PIN_COLOR);
                            return true;
                        }
                        if (params.length == 3
                                && params[0].isAssignableFrom(RegistryKey.class)
                                && params[1].isAssignableFrom(BlockPos.class)
                                && params[2].isAssignableFrom(String.class)) {
                            m.invoke(null, dimKey, wp.pos(), wp.shortTitle());
                            return true;
                        }
                    }
                }
            } catch (ClassNotFoundException ignored) {
                // Probe next candidate class
            } catch (Exception e) {
                ChestFinderClient.LOGGER.debug("[ChestFinder] Map Atlases marker hook '{}' skipped: {}", className, e.getMessage());
            }
        }
        return false;
    }

    private boolean tryRemoveViaMapAtlasesClientMarkers(RegistryKey<World> dimKey, ChestWaypoint wp) {
        String[] candidateClasses = {
                "pepjebs.mapatlases.client.MapAtlasesClient",
                "pepjebs.mapatlases.integration.moonlight.ClientMarkers",
                "pepjebs.mapatlases.client.markers.ClientWaypointManager"
        };
        for (String className : candidateClasses) {
            try {
                Class<?> clazz = Class.forName(className);
                for (Method m : clazz.getMethods()) {
                    String name = m.getName();
                    if ((name.equals("removeMarker") || name.equals("removeWaypoint") || name.equals("removeClientMarker"))
                            && m.getParameterCount() == 2) {
                        Class<?>[] params = m.getParameterTypes();
                        if (params[0].isAssignableFrom(RegistryKey.class) && params[1].isAssignableFrom(BlockPos.class)) {
                            m.invoke(null, dimKey, wp.pos());
                            return true;
                        }
                    }
                }
            } catch (ClassNotFoundException ignored) {
                // Probe next candidate class
            } catch (Exception e) {
                ChestFinderClient.LOGGER.debug("[ChestFinder] Map Atlases remove hook '{}' skipped: {}", className, e.getMessage());
            }
        }
        return false;
    }

    private void tryAddViaMoonlightClientMarkers(RegistryKey<World> dimKey, ChestWaypoint wp) {
        try {
            Class<?> clientMarkers = Class.forName("net.mehvahdjukaar.moonlight.api.map.client.MapDecorationClientManager");
            for (Method m : clientMarkers.getMethods()) {
                if (m.getName().equals("addClientMarker") && m.getParameterCount() == 3) {
                    m.invoke(null, dimKey, wp.pos(), Text.literal(wp.shortTitle()));
                    return;
                }
            }
        } catch (ClassNotFoundException ignored) {
            // Moonlight Lib optional dependency not installed
        } catch (Exception e) {
            ChestFinderClient.LOGGER.debug("[ChestFinder] Moonlight client marker fallback skipped: {}", e.getMessage());
        }
    }

    private void tryRemoveViaMoonlightClientMarkers(RegistryKey<World> dimKey, ChestWaypoint wp) {
        try {
            Class<?> clientMarkers = Class.forName("net.mehvahdjukaar.moonlight.api.map.client.MapDecorationClientManager");
            for (Method m : clientMarkers.getMethods()) {
                if (m.getName().equals("removeClientMarker") && m.getParameterCount() == 2) {
                    m.invoke(null, dimKey, wp.pos());
                    return;
                }
            }
        } catch (ClassNotFoundException ignored) {
            // Moonlight Lib optional dependency not installed
        } catch (Exception e) {
            ChestFinderClient.LOGGER.debug("[ChestFinder] Moonlight remove marker fallback skipped: {}", e.getMessage());
        }
    }
}
