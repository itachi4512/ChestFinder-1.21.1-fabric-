package com.chestfinder.gui;

import com.chestfinder.ChestFinderClient;
import com.chestfinder.search.SearchResult;
import com.chestfinder.storage.ContainerRecord;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Clean client-side search screen for finding stored items across scanned chests
 * and barrels, filtering by dimension, viewing verification status, and automatically
 * marking every matching container on all installed compatible map mods.
 */
public final class SearchScreen extends Screen {

    private static final int PANEL_WIDTH = 360;
    private static final int PANEL_HEIGHT = 236;
    private static final int ROW_HEIGHT = 34;

    private final Screen parent;
    private final boolean modEnabled;

    private TextFieldWidget searchField;
    private ButtonWidget searchButton;
    private ButtonWidget dimensionButton;
    private ButtonWidget clearMarkersButton;

    private final List<String> dimensionOptions = new ArrayList<>();
    private int selectedDimensionIndex = 0;

    private List<SearchResult> results = List.of();
    private String lastExecutedQuery = "";
    private boolean hasSearched = false;
    private int scrollOffset = 0;

    private int panelLeft;
    private int panelTop;
    private int listTop;
    private int listBottom;

    public SearchScreen(Screen parent) {
        super(Text.translatable("chestfinder.title"));
        this.parent = parent;
        this.modEnabled = ChestFinderClient.getInstance().isEnabled();
    }

    @Override
    protected void init() {
        super.init();

        this.panelLeft = (this.width - PANEL_WIDTH) / 2;
        this.panelTop = (this.height - PANEL_HEIGHT) / 2;

        if (!modEnabled) {
            this.addDrawableChild(ButtonWidget.builder(Text.literal("Back"), btn -> close())
                    .dimensions(this.panelLeft + (PANEL_WIDTH - 90) / 2, this.panelTop + PANEL_HEIGHT - 34, 90, 20)
                    .build());
            return;
        }

        buildDimensionOptions();

        int contentX = panelLeft + 12;
        int contentWidth = PANEL_WIDTH - 24;

        // Search input box
        int searchFieldWidth = contentWidth - 68;
        this.searchField = new TextFieldWidget(
                this.textRenderer,
                contentX,
                panelTop + 26,
                searchFieldWidth,
                20,
                Text.translatable("chestfinder.screen.search_placeholder")
        );
        this.searchField.setMaxLength(128);
        this.searchField.setPlaceholder(Text.translatable("chestfinder.screen.search_placeholder"));
        this.searchField.setText(lastExecutedQuery);
        this.addDrawableChild(this.searchField);
        this.setInitialFocus(this.searchField);

        // Search action button
        this.searchButton = ButtonWidget.builder(
                        Text.translatable("chestfinder.screen.search_button"),
                        btn -> performSearch()
                )
                .dimensions(contentX + searchFieldWidth + 4, panelTop + 26, 64, 20)
                .build();
        this.addDrawableChild(this.searchButton);

        // Dimension filter cycle button
        int dimBtnWidth = 156;
        this.dimensionButton = ButtonWidget.builder(
                        getDimensionButtonLabel(),
                        btn -> cycleDimensionFilter()
                )
                .dimensions(contentX, panelTop + 52, dimBtnWidth, 20)
                .build();
        this.addDrawableChild(this.dimensionButton);

        // Clear Markers button
        this.clearMarkersButton = ButtonWidget.builder(
                        Text.translatable("chestfinder.screen.clear_markers"),
                        btn -> {
                            ChestFinderClient.getInstance().getWaypointManager().clearActiveWaypoints();
                            this.results = List.of();
                            this.hasSearched = false;
                            this.scrollOffset = 0;
                        }
                )
                .dimensions(contentX + dimBtnWidth + 6, panelTop + 52, 96, 20)
                .build();
        this.addDrawableChild(this.clearMarkersButton);

        // Close button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), btn -> close())
                .dimensions(contentX + contentWidth - 70, panelTop + 52, 70, 20)
                .build());

        this.listTop = panelTop + 92;
        this.listBottom = panelTop + PANEL_HEIGHT - 12;
    }

    private void buildDimensionOptions() {
        dimensionOptions.clear();
        dimensionOptions.add(""); // Index 0 = All dimensions
        dimensionOptions.add("minecraft:overworld");
        dimensionOptions.add("minecraft:the_nether");
        dimensionOptions.add("minecraft:the_end");

        for (String knownDim : ChestFinderClient.getInstance().getDatabase().getKnownDimensions()) {
            if (!dimensionOptions.contains(knownDim)) {
                dimensionOptions.add(knownDim);
            }
        }
        if (selectedDimensionIndex >= dimensionOptions.size()) {
            selectedDimensionIndex = 0;
        }
    }

    private void cycleDimensionFilter() {
        if (dimensionOptions.isEmpty()) {
            return;
        }
        selectedDimensionIndex = (selectedDimensionIndex + 1) % dimensionOptions.size();
        dimensionButton.setMessage(getDimensionButtonLabel());
        if (hasSearched && !lastExecutedQuery.isBlank()) {
            performSearch();
        }
    }

    private Text getDimensionButtonLabel() {
        if (selectedDimensionIndex <= 0 || selectedDimensionIndex >= dimensionOptions.size()) {
            return Text.translatable("chestfinder.screen.dimension_all");
        }
        String dimId = dimensionOptions.get(selectedDimensionIndex);
        return Text.literal("Dim: " + ContainerRecord.formatDimensionLabel(dimId));
    }

    private void performSearch() {
        if (!modEnabled || searchField == null) {
            return;
        }
        String query = searchField.getText().trim();
        this.lastExecutedQuery = query;
        this.scrollOffset = 0;

        if (query.isEmpty()) {
            this.results = List.of();
            this.hasSearched = false;
            ChestFinderClient.getInstance().getWaypointManager().clearActiveWaypoints();
            return;
        }

        String dimFilter = dimensionOptions.get(selectedDimensionIndex);
        BlockPos playerPos = (client != null && client.player != null) ? client.player.getBlockPos() : null;

        this.results = ChestFinderClient.getInstance()
                .getSearchEngine()
                .search(query, dimFilter, playerPos);
        this.hasSearched = true;

        // Automatically create/update map markers for every matching chest across all active map mods
        ChestFinderClient.getInstance().getWaypointManager().applySearchResults(this.results);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (modEnabled && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            if (searchField != null && searchField.isFocused()) {
                performSearch();
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (modEnabled && !results.isEmpty()) {
            int maxVisible = Math.max(1, (listBottom - listTop) / ROW_HEIGHT);
            int maxOffset = Math.max(0, results.size() - maxVisible);
            scrollOffset = Math.max(0, Math.min(maxOffset, scrollOffset - (int) Math.signum(verticalAmount)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        // Main panel frame
        context.fill(panelLeft, panelTop, panelLeft + PANEL_WIDTH, panelTop + PANEL_HEIGHT, 0xE6181A20);
        context.drawBorder(panelLeft, panelTop, PANEL_WIDTH, PANEL_HEIGHT, 0xFF5A6270);

        if (!modEnabled) {
            renderCompatibilityWarning(context);
            super.render(context, mouseX, mouseY, delta);
            return;
        }

        // Header title & active map mod indicator
        context.drawTextWithShadow(
                this.textRenderer,
                Text.translatable("chestfinder.title"),
                panelLeft + 12,
                panelTop + 9,
                0xFFF5C542
        );

        String activeMaps = "Maps: " + ChestFinderClient.getInstance().getWaypointManager().getActiveIntegrationsLabel();
        int mapsWidth = this.textRenderer.getWidth(activeMaps);
        context.drawTextWithShadow(
                this.textRenderer,
                Text.literal(activeMaps),
                panelLeft + PANEL_WIDTH - mapsWidth - 12,
                panelTop + 9,
                0xFF9CD3A4
        );

        // Status line above results list
        renderStatusHeader(context);

        // Results viewport
        int listLeft = panelLeft + 12;
        int listRight = panelLeft + PANEL_WIDTH - 12;
        context.fill(listLeft, listTop, listRight, listBottom, 0xAA0E1015);
        context.drawBorder(listLeft, listTop, listRight - listLeft, listBottom - listTop, 0xFF333945);

        if (!hasSearched) {
            drawCenteredWrappedText(
                    context,
                    Text.translatable("chestfinder.screen.empty_prompt"),
                    panelLeft + PANEL_WIDTH / 2,
                    listTop + 44,
                    PANEL_WIDTH - 48,
                    0xFFB0B8C5
            );
        } else if (results.isEmpty()) {
            drawCenteredWrappedText(
                    context,
                    Text.translatable("chestfinder.screen.no_results", lastExecutedQuery),
                    panelLeft + PANEL_WIDTH / 2,
                    listTop + 44,
                    PANEL_WIDTH - 48,
                    0xFFE57373
            );
        } else {
            renderResultRows(context, listLeft + 4, listRight - 4);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderStatusHeader(DrawContext context) {
        int statusY = panelTop + 78;
        if (hasSearched && !results.isEmpty()) {
            int totalQty = results.stream().mapToInt(SearchResult::getQuantity).sum();
            String maps = ChestFinderClient.getInstance().getWaypointManager().getActiveIntegrationsLabel();
            Text summary = Text.translatable("chestfinder.screen.results_header", results.size(), totalQty, maps);
            context.drawTextWithShadow(this.textRenderer, summary, panelLeft + 12, statusY, 0xFFDCE3EC);
        } else {
            int tracked = ChestFinderClient.getInstance().getDatabase().size();
            context.drawTextWithShadow(
                    this.textRenderer,
                    Text.literal("Tracked containers in this world: " + tracked),
                    panelLeft + 12,
                    statusY,
                    0xFF9AA4B2
            );
        }
    }

    private void renderResultRows(DrawContext context, int rowLeft, int rowRight) {
        int maxVisible = Math.max(1, (listBottom - listTop - 4) / ROW_HEIGHT);
        int end = Math.min(results.size(), scrollOffset + maxVisible);

        for (int i = scrollOffset; i < end; i++) {
            SearchResult result = results.get(i);
            ContainerRecord container = result.getContainer();
            int rowY = listTop + 3 + (i - scrollOffset) * ROW_HEIGHT;

            int bgColor = ((i % 2) == 0) ? 0x66222630 : 0x661B1E27;
            context.fill(rowLeft, rowY, rowRight, rowY + ROW_HEIGHT - 2, bgColor);

            // Render item icon
            Identifier itemId = Identifier.tryParse(result.getMatchedItemId());
            if (itemId != null && Registries.ITEM.containsId(itemId)) {
                Item item = Registries.ITEM.get(itemId);
                context.drawItem(new ItemStack(item), rowLeft + 4, rowY + 8);
            }

            // Line 1: Item name, quantity, and container type
            String topLine = result.getMatchedItemDisplayName()
                    + " x" + result.getQuantity()
                    + "  [" + container.getContainerType().getDefaultLabel() + "]";
            context.drawTextWithShadow(this.textRenderer, Text.literal(topLine), rowLeft + 26, rowY + 4, 0xFFFFFFFF);

            // Line 2: Coordinates and dimension
            String coordLine = "XYZ: " + container.formatCoordinates()
                    + "  |  " + ContainerRecord.formatDimensionLabel(container.getDimension());
            context.drawTextWithShadow(this.textRenderer, Text.literal(coordLine), rowLeft + 26, rowY + 18, 0xFFB0C4DE);

            // Right-aligned verification freshness badge
            String badgeText = (result.isRecentlyVerified() ? "Verified" : "Recorded")
                    + " (" + result.formatAgeLabel() + ")";
            int badgeColor = result.isRecentlyVerified() ? 0xFF66BB6A : 0xFFFFB74D;
            int badgeWidth = this.textRenderer.getWidth(badgeText);
            context.drawTextWithShadow(
                    this.textRenderer,
                    Text.literal(badgeText),
                    rowRight - badgeWidth - 6,
                    rowY + 11,
                    badgeColor
            );
        }

        // Scroll indicator when results exceed viewport
        if (results.size() > maxVisible) {
            String scrollHint = (scrollOffset + 1) + "-" + end + " / " + results.size();
            int hintWidth = this.textRenderer.getWidth(scrollHint);
            context.drawTextWithShadow(
                    this.textRenderer,
                    Text.literal(scrollHint),
                    panelLeft + PANEL_WIDTH - hintWidth - 14,
                    panelTop + 78,
                    0xFF8C96A6
            );
        }
    }

    private void renderCompatibilityWarning(DrawContext context) {
        Text title = Text.translatable("chestfinder.warning.screen_title");
        int titleW = this.textRenderer.getWidth(title);
        context.drawTextWithShadow(
                this.textRenderer,
                title,
                panelLeft + (PANEL_WIDTH - titleW) / 2,
                panelTop + 28,
                0xFFFF6B6B
        );

        drawCenteredWrappedText(
                context,
                Text.translatable("chestfinder.warning.screen_body"),
                panelLeft + PANEL_WIDTH / 2,
                panelTop + 64,
                PANEL_WIDTH - 48,
                0xFFE0E6ED
        );
    }

    private void drawCenteredWrappedText(DrawContext context, Text text, int centerX, int startY, int maxWidth, int color) {
        List<OrderedText> lines = this.textRenderer.wrapLines(text, maxWidth);
        int y = startY;
        for (OrderedText line : lines) {
            int lineWidth = this.textRenderer.getWidth(line);
            context.drawTextWithShadow(this.textRenderer, line, centerX - lineWidth / 2, y, color);
            y += 12;
        }
    }

    @Override
    public void close() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) {
            client.setScreen(this.parent);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
