package com.chestfinder.gui;

import com.chestfinder.ChestFinderClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Custom 20x18 inventory button rendered immediately beside the vanilla
 * Knowledge Book (Recipe Book) button with a chest/search icon.
 */
public final class InventoryButton extends ButtonWidget {

    public static final int WIDTH = 20;
    public static final int HEIGHT = 18;

    private static final Identifier TEXTURE_NORMAL = Identifier.of(
            ChestFinderClient.MOD_ID,
            "textures/gui/chestfinder_button.png"
    );
    private static final Identifier TEXTURE_HOVER = Identifier.of(
            ChestFinderClient.MOD_ID,
            "textures/gui/chestfinder_button_hover.png"
    );
    private static final Identifier TEXTURE_DISABLED = Identifier.of(
            ChestFinderClient.MOD_ID,
            "textures/gui/chestfinder_button_disabled.png"
    );

    private final boolean modEnabled;

    public InventoryButton(int x, int y, Screen parentScreen) {
        super(
                x,
                y,
                WIDTH,
                HEIGHT,
                Text.translatable("chestfinder.title"),
                button -> onButtonClicked(parentScreen),
                DEFAULT_NARRATION_SUPPLIER
        );
        this.modEnabled = ChestFinderClient.getInstance().isEnabled();
        this.setTooltip(Tooltip.of(Text.translatable(
                modEnabled ? "chestfinder.button.tooltip" : "chestfinder.button.disabled.tooltip"
        )));
    }

    private static void onButtonClicked(Screen parentScreen) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) {
            client.setScreen(new SearchScreen(parentScreen));
        }
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        Identifier texture;
        if (!modEnabled) {
            texture = TEXTURE_DISABLED;
        } else if (this.isHovered() || this.isFocused()) {
            texture = TEXTURE_HOVER;
        } else {
            texture = TEXTURE_NORMAL;
        }
        context.drawTexture(texture, this.getX(), this.getY(), 0, 0, this.width, this.height, WIDTH, HEIGHT);
    }
}
