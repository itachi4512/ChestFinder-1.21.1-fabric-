package com.chestfinder.scanner;

import com.chestfinder.ChestFinderClient;
import com.chestfinder.storage.ContainerRecord;
import com.chestfinder.storage.ContainerType;
import com.chestfinder.storage.StorageDatabase;
import com.chestfinder.waypoint.WaypointManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.TrappedChestBlock;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Observes containers legitimately opened by the player and records their contents.
 * Supports normal chests, trapped chests, double chests (canonicalized to one record),
 * and barrels. Explicitly excludes shulker boxes and never accesses unopened containers.
 */
public final class StorageScanner {

    private static final long INTERACTION_TIMEOUT_MS = 4000L;

    private final StorageDatabase database;
    private final WaypointManager waypointManager;

    private PendingContainer pendingContainer;
    private ActiveSession activeSession;

    public StorageScanner(StorageDatabase database, WaypointManager waypointManager) {
        this.database = database;
        this.waypointManager = waypointManager;
    }

    /**
     * Registers client-side interaction and tick hooks.
     */
    public void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClient() || !ChestFinderClient.getInstance().isEnabled()) {
                return ActionResult.PASS;
            }
            BlockPos pos = hitResult.getBlockPos();
            BlockState state = world.getBlockState(pos);
            Block block = state.getBlock();

            // Explicitly exclude shulker boxes
            if (block instanceof ShulkerBoxBlock) {
                pendingContainer = null;
                return ActionResult.PASS;
            }

            ResolvedContainer resolved = resolveSupportedContainer(world, pos, state);
            if (resolved != null) {
                pendingContainer = new PendingContainer(
                        resolved.canonicalPos,
                        resolved.secondaryPos,
                        world.getRegistryKey().getValue().toString(),
                        resolved.type,
                        System.currentTimeMillis()
                );
            } else {
                pendingContainer = null;
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        if (!ChestFinderClient.getInstance().isEnabled()) {
            activeSession = null;
            pendingContainer = null;
            return;
        }
        if (client.player == null || client.world == null) {
            activeSession = null;
            pendingContainer = null;
            return;
        }

        // Handle currently open container screen
        if (client.currentScreen instanceof GenericContainerScreen containerScreen) {
            ScreenHandler handler = containerScreen.getScreenHandler();
            if (handler instanceof ShulkerBoxScreenHandler) {
                activeSession = null;
                return;
            }
            if (!(handler instanceof GenericContainerScreenHandler genericHandler)) {
                return;
            }

            if (activeSession == null || activeSession.syncId != genericHandler.syncId) {
                if (pendingContainer != null
                        && System.currentTimeMillis() - pendingContainer.timestampMs <= INTERACTION_TIMEOUT_MS) {
                    activeSession = new ActiveSession(genericHandler.syncId, pendingContainer);
                    pendingContainer = null;
                } else {
                    return;
                }
            }

            scanHandler(genericHandler, activeSession);
        } else if (activeSession != null) {
            // Container screen closed; clear active session
            activeSession = null;
        }
    }

    private void scanHandler(GenericContainerScreenHandler handler, ActiveSession session) {
        int containerSlotCount = handler.getRows() * 9;
        int limit = Math.min(containerSlotCount, handler.slots.size());

        Map<String, Integer> scannedItems = new LinkedHashMap<>();
        for (int i = 0; i < limit; i++) {
            Slot slot = handler.slots.get(i);
            ItemStack stack = slot.getStack();
            if (stack == null || stack.isEmpty()) {
                continue;
            }
            String itemId = Registries.ITEM.getId(stack.getItem()).toString();
            scannedItems.merge(itemId, stack.getCount(), Integer::sum);
        }

        // Wait until first snapshot or an actual change occurs during the open session
        if (session.lastSnapshot != null && Objects.equals(session.lastSnapshot, scannedItems)) {
            return;
        }

        session.lastSnapshot = scannedItems;

        // If this is a double chest, remove any orphaned record stored under the secondary half
        if (session.info.secondaryPos != null) {
            String secondaryKey = ContainerRecord.buildKey(session.info.dimension, session.info.secondaryPos);
            database.removeRecord(secondaryKey);
        }

        ContainerRecord record = new ContainerRecord(
                session.info.canonicalPos.getX(),
                session.info.canonicalPos.getY(),
                session.info.canonicalPos.getZ(),
                session.info.dimension,
                session.info.type,
                scannedItems,
                System.currentTimeMillis()
        );

        boolean changed = database.upsertRecord(record);
        if (changed) {
            waypointManager.onContainerUpdated(record);
        }
    }

    private static ResolvedContainer resolveSupportedContainer(World world, BlockPos pos, BlockState state) {
        Block block = state.getBlock();

        if (block instanceof BarrelBlock) {
            return new ResolvedContainer(pos.toImmutable(), null, ContainerType.BARREL);
        }

        if (block instanceof ChestBlock) {
            ChestType chestType = state.contains(ChestBlock.CHEST_TYPE)
                    ? state.get(ChestBlock.CHEST_TYPE)
                    : ChestType.SINGLE;

            if (chestType != ChestType.SINGLE) {
                Direction offsetDir = ChestBlock.getFacing(state);
                BlockPos otherHalf = pos.offset(offsetDir);
                BlockState otherState = world.getBlockState(otherHalf);
                if (otherState.getBlock() == block) {
                    BlockPos canonical = compareBlockPos(pos, otherHalf) <= 0
                            ? pos.toImmutable()
                            : otherHalf.toImmutable();
                    BlockPos secondary = canonical.equals(pos)
                            ? otherHalf.toImmutable()
                            : pos.toImmutable();
                    return new ResolvedContainer(canonical, secondary, ContainerType.DOUBLE_CHEST);
                }
            }

            ContainerType singleType = (block instanceof TrappedChestBlock)
                    ? ContainerType.TRAPPED_CHEST
                    : ContainerType.CHEST;
            return new ResolvedContainer(pos.toImmutable(), null, singleType);
        }

        return null;
    }

    private static int compareBlockPos(BlockPos a, BlockPos b) {
        if (a.getX() != b.getX()) return Integer.compare(a.getX(), b.getX());
        if (a.getY() != b.getY()) return Integer.compare(a.getY(), b.getY());
        return Integer.compare(a.getZ(), b.getZ());
    }

    public void reset() {
        pendingContainer = null;
        activeSession = null;
    }

    private record ResolvedContainer(BlockPos canonicalPos, BlockPos secondaryPos, ContainerType type) {}

    private record PendingContainer(
            BlockPos canonicalPos,
            BlockPos secondaryPos,
            String dimension,
            ContainerType type,
            long timestampMs
    ) {}

    private static final class ActiveSession {
        final int syncId;
        final PendingContainer info;
        Map<String, Integer> lastSnapshot;

        ActiveSession(int syncId, PendingContainer info) {
            this.syncId = syncId;
            this.info = info;
        }
    }
}
