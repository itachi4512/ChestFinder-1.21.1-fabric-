package com.chestfinder.search;

import com.chestfinder.storage.ContainerRecord;
import com.chestfinder.storage.StorageDatabase;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Resolves exact item names or registry IDs against Minecraft's item registry
 * and returns all matching scanned containers with optional dimension filtering.
 */
public final class SearchEngine {

    private final StorageDatabase database;

    public SearchEngine(StorageDatabase database) {
        this.database = database;
    }

    /**
     * Searches all stored containers for an exact item name (case-insensitive)
     * or exact registry ID (with or without the "minecraft:" namespace).
     *
     * @param rawQuery        Exact item name (e.g., "Diamond") or registry ID (e.g., "minecraft:diamond")
     * @param dimensionFilter Optional dimension ID (e.g., "minecraft:overworld"), or null/blank for all dimensions
     * @param playerPos       Optional current player position for distance-based tie-breaking
     * @return Ordered list of matching containers
     */
    public List<SearchResult> search(String rawQuery, String dimensionFilter, BlockPos playerPos) {
        if (rawQuery == null || rawQuery.isBlank()) {
            return List.of();
        }

        String normalizedQuery = rawQuery.trim().toLowerCase(Locale.ROOT);
        Set<String> targetItemIds = resolveExactItemIds(normalizedQuery);
        if (targetItemIds.isEmpty()) {
            return List.of();
        }

        long now = System.currentTimeMillis();
        List<SearchResult> results = new ArrayList<>();

        for (ContainerRecord record : database.getAllRecords()) {
            if (dimensionFilter != null && !dimensionFilter.isBlank()
                    && !dimensionFilter.equals(record.getDimension())) {
                continue;
            }

            for (String itemId : targetItemIds) {
                int count = record.getItemCount(itemId);
                if (count > 0) {
                    boolean recentlyVerified = database.isRecentlyVerified(record);
                    long ageMs = Math.max(0L, now - record.getLastScannedTimestamp());
                    results.add(new SearchResult(
                            record,
                            itemId,
                            resolveDisplayName(itemId),
                            count,
                            recentlyVerified,
                            ageMs
                    ));
                }
            }
        }

        results.sort(buildComparator(playerPos));
        return results;
    }

    /**
     * Matches the query against:
     * 1. Exact registry ID (e.g. "minecraft:oak_planks")
     * 2. Exact path in the "minecraft" namespace (e.g. "oak_planks" -> "minecraft:oak_planks")
     * 3. Exact localized display name (case-insensitive, e.g. "Oak Planks")
     */
    private Set<String> resolveExactItemIds(String normalizedQuery) {
        Set<String> matched = new LinkedHashSet<>();

        // 1. Direct registry ID lookup
        Identifier parsedId = Identifier.tryParse(normalizedQuery);
        if (parsedId != null && Registries.ITEM.containsId(parsedId)) {
            matched.add(parsedId.toString());
        }

        // 2. Default "minecraft:" namespace lookup when user omits namespace
        if (!normalizedQuery.contains(":")) {
            Identifier defaultNsId = Identifier.tryParse("minecraft:" + normalizedQuery);
            if (defaultNsId != null && Registries.ITEM.containsId(defaultNsId)) {
                matched.add(defaultNsId.toString());
            }
        }

        // 3. Exact case-insensitive localized item name match
        for (Item item : Registries.ITEM) {
            String itemName = item.getName().getString().trim().toLowerCase(Locale.ROOT);
            if (itemName.equals(normalizedQuery)) {
                matched.add(Registries.ITEM.getId(item).toString());
            }
        }

        // 4. Fallback: allow matching an exact modded/removed item registry ID present in the database
        if (matched.isEmpty()) {
            for (ContainerRecord record : database.getAllRecords()) {
                for (String storedId : record.getItems().keySet()) {
                    if (storedId.toLowerCase(Locale.ROOT).equals(normalizedQuery)) {
                        matched.add(storedId);
                    }
                }
            }
        }

        return matched;
    }

    public static String resolveDisplayName(String registryId) {
        Identifier id = Identifier.tryParse(registryId);
        if (id != null && Registries.ITEM.containsId(id)) {
            return Registries.ITEM.get(id).getName().getString();
        }
        return registryId;
    }

    private static Comparator<SearchResult> buildComparator(BlockPos playerPos) {
        return Comparator
                .comparing(SearchResult::isRecentlyVerified, Comparator.reverseOrder())
                .thenComparingInt(SearchResult::getQuantity).reversed()
                .thenComparingDouble(result -> {
                    if (playerPos == null) {
                        return 0.0;
                    }
                    return result.getContainer().toBlockPos().getSquaredDistance(playerPos);
                });
    }
}
