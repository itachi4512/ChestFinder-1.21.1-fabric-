package com.chestfinder.search;

import com.chestfinder.storage.ContainerRecord;

/**
 * Single matching container result produced by {@link SearchEngine}.
 */
public final class SearchResult {

    private final ContainerRecord container;
    private final String matchedItemId;
    private final String matchedItemDisplayName;
    private final int quantity;
    private final boolean recentlyVerified;
    private final long ageMillis;

    public SearchResult(
            ContainerRecord container,
            String matchedItemId,
            String matchedItemDisplayName,
            int quantity,
            boolean recentlyVerified,
            long ageMillis
    ) {
        this.container = container;
        this.matchedItemId = matchedItemId;
        this.matchedItemDisplayName = matchedItemDisplayName;
        this.quantity = quantity;
        this.recentlyVerified = recentlyVerified;
        this.ageMillis = Math.max(0L, ageMillis);
    }

    public ContainerRecord getContainer() {
        return container;
    }

    public String getMatchedItemId() {
        return matchedItemId;
    }

    public String getMatchedItemDisplayName() {
        return matchedItemDisplayName;
    }

    public int getQuantity() {
        return quantity;
    }

    public boolean isRecentlyVerified() {
        return recentlyVerified;
    }

    public long getAgeMillis() {
        return ageMillis;
    }

    public String formatAgeLabel() {
        long seconds = ageMillis / 1000L;
        if (seconds < 60L) {
            return "just now";
        }
        long minutes = seconds / 60L;
        if (minutes < 60L) {
            return minutes + "m ago";
        }
        long hours = minutes / 60L;
        if (hours < 24L) {
            return hours + "h ago";
        }
        long days = hours / 24L;
        return days + "d ago";
    }
}
