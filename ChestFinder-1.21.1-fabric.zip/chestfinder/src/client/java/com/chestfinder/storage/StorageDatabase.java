package com.chestfinder.storage;

import com.chestfinder.ChestFinderClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Persistent local storage database with separate JSON files per singleplayer world
 * or multiplayer server. Writes are performed asynchronously and atomically.
 */
public final class StorageDatabase {

    private static final int SCHEMA_VERSION = 1;
    private static final long RECENTLY_VERIFIED_WINDOW_MS = TimeUnit.MINUTES.toMillis(5);

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();

    private final Path databaseDir;
    private final ExecutorService saveExecutor;
    private final Map<String, ContainerRecord> records = new ConcurrentHashMap<>();
    private final Set<String> verifiedThisSession = ConcurrentHashMap.newKeySet();
    private final AtomicBoolean saveScheduled = new AtomicBoolean(false);

    private volatile String activeWorldKey;
    private volatile Path activeDatabaseFile;

    public StorageDatabase() {
        this.databaseDir = FabricLoader.getInstance()
                .getConfigDir()
                .resolve("chestfinder")
                .resolve("worlds");
        this.saveExecutor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "ChestFinder-DB-IO");
            thread.setDaemon(true);
            return thread;
        });
    }

    /**
     * Loads the database corresponding to the currently joined singleplayer world or multiplayer server.
     */
    public synchronized void loadForCurrentWorld(MinecraftClient client) {
        String worldKey = resolveWorldKey(client);
        if (worldKey == null) {
            return;
        }
        if (worldKey.equals(this.activeWorldKey)) {
            return;
        }

        flushSync();
        this.records.clear();
        this.verifiedThisSession.clear();
        this.activeWorldKey = worldKey;
        this.activeDatabaseFile = databaseDir.resolve(worldKey + ".json");

        if (!Files.exists(activeDatabaseFile)) {
            ChestFinderClient.LOGGER.info("[ChestFinder] Created new storage database for world '{}'.", worldKey);
            return;
        }

        try (Reader reader = Files.newBufferedReader(activeDatabaseFile, StandardCharsets.UTF_8)) {
            Type wrapperType = new TypeToken<DatabaseFile>() {}.getType();
            DatabaseFile data = GSON.fromJson(reader, wrapperType);
            if (data != null && data.containers != null) {
                for (ContainerRecord record : data.containers) {
                    if (record != null && record.getDimension() != null && record.getContainerType() != null) {
                        records.put(record.getCanonicalKey(), record);
                    }
                }
            }
            ChestFinderClient.LOGGER.info(
                    "[ChestFinder] Loaded {} container record(s) for world '{}'.",
                    records.size(),
                    worldKey
            );
        } catch (IOException | JsonParseException e) {
            ChestFinderClient.LOGGER.error("[ChestFinder] Failed to read storage database '{}'.", activeDatabaseFile, e);
        }
    }

    /**
     * Flushes pending writes and clears in-memory state when disconnecting from a world/server.
     */
    public synchronized void unloadCurrentWorld() {
        flushSync();
        records.clear();
        verifiedThisSession.clear();
        activeWorldKey = null;
        activeDatabaseFile = null;
    }

    /**
     * Inserts or updates a container record. Returns true if the record was newly added
     * or its contents/type changed compared to the previously stored snapshot.
     */
    public boolean upsertRecord(ContainerRecord record) {
        if (activeDatabaseFile == null || record == null) {
            return false;
        }
        String key = record.getCanonicalKey();
        ContainerRecord previous = records.put(key, record);
        verifiedThisSession.add(key);

        boolean changed = previous == null
                || previous.getContainerType() != record.getContainerType()
                || !previous.hasSameContents(record.getItems());

        scheduleAsyncSave();
        return changed;
    }

    /**
     * Removes a stale record (for example, if a container half was merged into a double chest
     * whose canonical position is the other half).
     */
    public boolean removeRecord(String canonicalKey) {
        if (canonicalKey == null) {
            return false;
        }
        ContainerRecord removed = records.remove(canonicalKey);
        verifiedThisSession.remove(canonicalKey);
        if (removed != null) {
            scheduleAsyncSave();
            return true;
        }
        return false;
    }

    public Optional<ContainerRecord> getRecord(String canonicalKey) {
        return Optional.ofNullable(records.get(canonicalKey));
    }

    public Collection<ContainerRecord> getAllRecords() {
        return Collections.unmodifiableCollection(records.values());
    }

    /**
     * Returns all distinct dimension IDs currently stored in this world's database.
     */
    public List<String> getKnownDimensions() {
        Set<String> dims = new TreeSet<>();
        for (ContainerRecord record : records.values()) {
            dims.add(record.getDimension());
        }
        return new ArrayList<>(dims);
    }

    /**
     * Distinguishes recently verified containers (scanned during the current session
     * within the verification window) from older previously recorded data.
     */
    public boolean isRecentlyVerified(ContainerRecord record) {
        if (record == null) {
            return false;
        }
        long ageMs = Math.max(0L, System.currentTimeMillis() - record.getLastScannedTimestamp());
        return verifiedThisSession.contains(record.getCanonicalKey())
                && ageMs <= RECENTLY_VERIFIED_WINDOW_MS;
    }

    public String getActiveWorldKey() {
        return activeWorldKey;
    }

    public int size() {
        return records.size();
    }

    private void scheduleAsyncSave() {
        final Path targetFile = this.activeDatabaseFile;
        if (targetFile == null) {
            return;
        }
        if (saveScheduled.compareAndSet(false, true)) {
            saveExecutor.submit(() -> {
                try {
                    saveScheduled.set(false);
                    writeSnapshot(targetFile);
                } catch (Exception e) {
                    ChestFinderClient.LOGGER.error("[ChestFinder] Asynchronous save failed.", e);
                }
            });
        }
    }

    private void flushSync() {
        Path targetFile = this.activeDatabaseFile;
        if (targetFile == null || records.isEmpty()) {
            return;
        }
        writeSnapshot(targetFile);
    }

    private void writeSnapshot(Path targetFile) {
        try {
            Files.createDirectories(targetFile.getParent());
            DatabaseFile payload = new DatabaseFile();
            payload.schemaVersion = SCHEMA_VERSION;
            payload.worldKey = activeWorldKey;
            payload.savedAt = System.currentTimeMillis();
            payload.containers = new ArrayList<>(records.values());

            Path tempFile = targetFile.resolveSibling(targetFile.getFileName() + ".tmp");
            try (Writer writer = Files.newBufferedWriter(tempFile, StandardCharsets.UTF_8)) {
                GSON.toJson(payload, writer);
            }
            Files.move(tempFile, targetFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            // Fallback to non-atomic move if filesystem does not support ATOMIC_MOVE
            try {
                Path tempFile = targetFile.resolveSibling(targetFile.getFileName() + ".tmp");
                if (Files.exists(tempFile)) {
                    Files.move(tempFile, targetFile, StandardCopyOption.REPLACE_EXISTING);
                }
            } catch (IOException ex) {
                ChestFinderClient.LOGGER.error("[ChestFinder] Failed to persist database to '{}'.", targetFile, ex);
            }
        }
    }

    public void shutdown() {
        flushSync();
        saveExecutor.shutdown();
        try {
            if (!saveExecutor.awaitTermination(3, TimeUnit.SECONDS)) {
                saveExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            saveExecutor.shutdownNow();
        }
    }

    private static String resolveWorldKey(MinecraftClient client) {
        if (client == null) {
            return null;
        }
        IntegratedServer integratedServer = client.getServer();
        if (integratedServer != null) {
            Path root = integratedServer.getSavePath(WorldSavePath.ROOT).normalize();
            Path folderName = root.getFileName();
            String rawName = folderName != null ? folderName.toString() : integratedServer.getSaveProperties().getLevelName();
            return "sp_" + sanitizeFilename(rawName);
        }

        ServerInfo serverInfo = client.getCurrentServerEntry();
        if (serverInfo != null) {
            String prefix = serverInfo.isRealm() ? "realm_" : "mp_";
            String identifier = serverInfo.address != null && !serverInfo.address.isBlank()
                    ? serverInfo.address
                    : serverInfo.name;
            return prefix + sanitizeFilename(identifier);
        }

        return null;
    }

    private static String sanitizeFilename(String input) {
        if (input == null || input.isBlank()) {
            return "unknown_world";
        }
        return input.trim()
                .toLowerCase()
                .replaceAll("[^a-z0-9._-]+", "_")
                .replaceAll("_+", "_");
    }

    private static final class DatabaseFile {
        int schemaVersion;
        String worldKey;
        long savedAt;
        List<ContainerRecord> containers;
    }
}
