package com.chestfinder.storage;

import net.minecraft.text.Text;

/**
 * Supported scannable storage container types.
 * Shulker boxes are intentionally excluded.
 */
public enum ContainerType {
    CHEST("chestfinder.container.chest", "Chest"),
    TRAPPED_CHEST("chestfinder.container.trapped_chest", "Trapped Chest"),
    DOUBLE_CHEST("chestfinder.container.double_chest", "Double Chest"),
    BARREL("chestfinder.container.barrel", "Barrel");

    private final String translationKey;
    private final String defaultLabel;

    ContainerType(String translationKey, String defaultLabel) {
        this.translationKey = translationKey;
        this.defaultLabel = defaultLabel;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public String getDefaultLabel() {
        return defaultLabel;
    }

    public Text getDisplayText() {
        return Text.translatable(translationKey);
    }
}
