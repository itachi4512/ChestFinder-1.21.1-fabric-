package com.chestfinder.storage;

import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Persistent record of a single scanned storage container (chest, trapped chest,
 * canonical double chest, or barrel) in a specific dimension.
 */
public final class ContainerRecord {

    private final int x;
    private final int y;
    private final int z;
    private final String dimension;
    private final ContainerType containerType;
    private final Map<String, Integer> items;
    private final long lastScannedTimestamp;

    public ContainerRecord(
            int x,
            int y,
            int z,
            String dimension,
            ContainerType containerType,
            Map<String, Integer> items,
            long lastScannedTimestamp
    ) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.dimension = Objects.requireNonNull(dimension, "dimension");
        this.containerType = Objects.requireNonNull(containerType, "containerType");
        this.items = items == null ? new LinkedHashMap<>() : new LinkedHashMap<>(items);
        this.lastScannedTimestamp = lastScannedTimestamp;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getZ() {
        return z;
    }

    public BlockPos toBlockPos() {
        return new BlockPos(x, y, z);
    }

    public String getDimension() {
        return dimension;
    }

    public ContainerType getContainerType() {
        return containerType;
    }

    /**
     * Unmodifiable map of item registry ID (e.g. "minecraft:diamond") to total quantity.
     */
    public Map<String, Integer> getItems() {
        return Collections.unmodifiableMap(items);
    }

    public int getItemCount(String registryId) {
        return items.getOrDefault(registryId, 0);
    }

    public long getLastScannedTimestamp() {
        return lastScannedTimestamp;
    }

    /**
     * Deterministic unique key for deduplicating containers and map waypoints.
     */
    public String getCanonicalKey() {
        return buildKey(dimension, x, y, z);
    }

    public static String buildKey(String dimension, BlockPos pos) {
        return buildKey(dimension, pos.getX(), pos.getY(), pos.getZ());
    }

    public static String buildKey(String dimension, int x, int y, int z) {
        return dimension + "@" + x + "," + y + "," + z;
    }

    public boolean hasSameContents(Map<String, Integer> otherItems) {
        return Objects.equals(this.items, otherItems);
    }

    public String formatCoordinates() {
        return x + ", " + y + ", " + z;
    }

    public static String formatDimensionLabel(String dimensionId) {
        if (dimensionId == null) {
            return "Unknown";
        }
        return switch (dimensionId) {
            case "minecraft:overworld" -> "Overworld";
            case "minecraft:the_nether" -> "The Nether";
            case "minecraft:the_end" -> "The End";
            default -> {
                int colon = dimensionId.indexOf(':');
                String path = colon >= 0 ? dimensionId.substring(colon + 1) : dimensionId;
                yield path.replace('_', ' ');
            }
        };
    }
}
