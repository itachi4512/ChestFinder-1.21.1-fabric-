package com.chestfinder.mixin;

import com.chestfinder.gui.InventoryButton;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.AbstractInventoryScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds the ChestFinder button immediately beside the vanilla Knowledge Book
 * (Recipe Book) button in the player's inventory screen and keeps its position
 * synchronized when the Recipe Book panel opens or closes.
 */
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin extends AbstractInventoryScreen<PlayerScreenHandler> {

    // Vanilla Recipe Book button is at (this.x + 104, this.height / 2 - 22), width 20.
    // Place ChestFinder immediately to its right with a 2px gap.
    @Unique
    private static final int BUTTON_OFFSET_X = 126;

    @Unique
    private static final int BUTTON_OFFSET_Y = -22;

    @Unique
    private InventoryButton chestFinderButton;

    protected InventoryScreenMixin(PlayerScreenHandler screenHandler, PlayerInventory playerInventory, Text text) {
        super(screenHandler, playerInventory, text);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void chestfinder$onInit(CallbackInfo ci) {
        int buttonX = this.x + BUTTON_OFFSET_X;
        int buttonY = this.height / 2 + BUTTON_OFFSET_Y;
        this.chestFinderButton = new InventoryButton(buttonX, buttonY, this);
        this.addDrawableChild(this.chestFinderButton);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void chestfinder$syncButtonPosition(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.chestFinderButton != null) {
            this.chestFinderButton.setPosition(this.x + BUTTON_OFFSET_X, this.height / 2 + BUTTON_OFFSET_Y);
        }
    }
}
