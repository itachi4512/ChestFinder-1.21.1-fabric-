package com.chestfinder;

import com.chestfinder.scanner.StorageScanner;
import com.chestfinder.search.SearchEngine;
import com.chestfinder.storage.StorageDatabase;
import com.chestfinder.waypoint.WaypointManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main client entrypoint for ChestFinder (Minecraft 1.21.1 Fabric).
 *
 * ChestFinder requires at least one supported map mod (Xaero's Minimap,
 * Xaero's World Map, JourneyMap, or Map Atlases) to operate. If none is
 * installed, scanning and searching are disabled and a compatibility warning
 * is shown to the player.
 */
public final class ChestFinderClient implements ClientModInitializer {

    public static final String MOD_ID = "chestfinder";
    public static final Logger LOGGER = LoggerFactory.getLogger("ChestFinder");

    private static ChestFinderClient instance;

    private StorageDatabase database;
    private SearchEngine searchEngine;
    private WaypointManager waypointManager;
    private StorageScanner storageScanner;
    private boolean enabled;

    public static ChestFinderClient getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        this.database = new StorageDatabase();
        this.searchEngine = new SearchEngine(database);
        this.waypointManager = new WaypointManager();
        this.enabled = waypointManager.hasSupportedMapMod();

        if (!enabled) {
            LOGGER.warn(
                    "[ChestFinder] No supported map mod detected (Xaero's Minimap, Xaero's World Map, JourneyMap, or Map Atlases). ChestFinder is disabled."
            );
        } else {
            LOGGER.info(
                    "[ChestFinder] Enabled with active map integration(s): {}",
                    waypointManager.getActiveIntegrationsLabel()
            );
            this.storageScanner = new StorageScanner(database, waypointManager);
            this.storageScanner.register();
        }

        registerLifecycleEvents();
    }

    private void registerLifecycleEvents() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            // Re-evaluate in case a runtime plugin (e.g. JourneyMap) finished initializing
            this.enabled = waypointManager.hasSupportedMapMod();

            if (!enabled) {
                client.execute(() -> {
                    if (client.player != null) {
                        client.player.sendMessage(
                                Text.translatable("chestfinder.warning.no_map_mod").formatted(Formatting.RED),
                                false
                        );
                    }
                });
                return;
            }

            if (this.storageScanner == null) {
                this.storageScanner = new StorageScanner(database, waypointManager);
                this.storageScanner.register();
            }

            database.loadForCurrentWorld(client);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            if (storageScanner != null) {
                storageScanner.reset();
            }
            waypointManager.clearActiveWaypoints();
            database.unloadCurrentWorld();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            waypointManager.clearActiveWaypoints();
            database.shutdown();
        });
    }

    public boolean isEnabled() {
        return enabled || (waypointManager != null && waypointManager.hasSupportedMapMod());
    }

    public StorageDatabase getDatabase() {
        return database;
    }

    public SearchEngine getSearchEngine() {
        return searchEngine;
    }

    public WaypointManager getWaypointManager() {
        return waypointManager;
    }
}
