package com.chestfinder.waypoint;

import com.chestfinder.storage.ContainerRecord;
import com.chestfinder.storage.ContainerType;
import net.minecraft.util.math.BlockPos;

/**
 * Standardized waypoint payload passed to every active map-mod integration.
 */
public record ChestWaypoint(
        String id,
        String label,
        String itemId,
        String itemDisplayName,
        int quantity,
        BlockPos pos,
        String dimension,
        ContainerType containerType,
        boolean recentlyVerified
) {
    public static final String ID_PREFIX = "chestfinder_";

    public static String buildId(ContainerRecord record) {
        return ID_PREFIX
                + record.getDimension().replace(':', '_')
                + "_" + record.getX()
                + "_" + record.getY()
                + "_" + record.getZ();
    }

    public String formattedTitle() {
        String freshness = recentlyVerified ? "Verified" : "Recorded";
        return String.format(
                "[Chest] %s x%d (%d, %d, %d | %s | %s)",
                itemDisplayName,
                quantity,
                pos.getX(),
                pos.getY(),
                pos.getZ(),
                ContainerRecord.formatDimensionLabel(dimension),
                freshness
        );
    }

    public String shortTitle() {
        return String.format("[CF] %s x%d (%s)", itemDisplayName, quantity, containerType.getDefaultLabel());
    }
}
