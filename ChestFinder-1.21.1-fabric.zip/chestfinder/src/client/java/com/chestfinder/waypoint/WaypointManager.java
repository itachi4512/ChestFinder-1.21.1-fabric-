package com.chestfinder.waypoint;

import com.chestfinder.ChestFinderClient;
import com.chestfinder.integration.JourneyMapIntegration;
import com.chestfinder.integration.MapAtlasIntegration;
import com.chestfinder.integration.MapIntegration;
import com.chestfinder.integration.XaeroIntegration;
import com.chestfinder.search.SearchResult;
import com.chestfinder.storage.ContainerRecord;
import net.fabricmc.loader.api.FabricLoader;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Coordinates waypoint creation, deduplication, updates, and cleanup simultaneously
 * across all installed supported map mods (Xaero's Minimap, Xaero's World Map,
 * JourneyMap, and Map Atlases).
 *
 * ChestFinder deliberately provides NO standalone map or waypoint renderer.
 */
public final class WaypointManager {

    private final List<MapIntegration> integrations = new ArrayList<>();
    private final Map<String, ChestWaypoint> activeWaypoints = new LinkedHashMap<>();

    private String activeSearchItemId;
    private String activeSearchDisplayName;

    public WaypointManager() {
        discoverIntegrations();
    }

    private void discoverIntegrations() {
        // 1. Xaero's Minimap and/or Xaero's World Map
        XaeroIntegration xaero = new XaeroIntegration();
        if (xaero.isAvailable()) {
            integrations.add(xaero);
        }

        // 2. JourneyMap (loaded safely via JourneyMap entrypoint when installed)
        if (FabricLoader.getInstance().isModLoaded(JourneyMapIntegration.MOD_JOURNEYMAP)) {
            JourneyMapIntegration jm = JourneyMapIntegration.getActiveInstance();
            if (jm != null) {
                integrations.add(jm);
            }
        }

        // 3. Map Atlases
        MapAtlasIntegration mapAtlases = new MapAtlasIntegration();
        if (mapAtlases.isAvailable()) {
            integrations.add(mapAtlases);
        }
    }

    /**
     * Allows late-initializing plugin entrypoints (such as JourneyMap's IClientPlugin)
     * to attach themselves once their API becomes ready.
     */
    public synchronized void registerRuntimeIntegration(MapIntegration integration) {
        if (integration == null || !integration.isAvailable()) {
            return;
        }
        boolean alreadyPresent = integrations.stream()
                .anyMatch(existing -> existing.getClass().equals(integration.getClass()));
        if (!alreadyPresent) {
            integrations.add(integration);
            ChestFinderClient.LOGGER.info("[ChestFinder] Registered runtime map integration: {}", integration.getDisplayName());
        }
    }

    /**
     * Returns true if at least one supported mapping mod is installed.
     * Checks both active integrations and FabricLoader mod presence (for JourneyMap
     * before its plugin initialize callback fires).
     */
    public boolean hasSupportedMapMod() {
        if (!integrations.isEmpty()) {
            return true;
        }
        FabricLoader loader = FabricLoader.getInstance();
        return loader.isModLoaded("xaerominimap")
                || loader.isModLoaded("xaerominimapfair")
                || loader.isModLoaded("xaeroworldmap")
                || loader.isModLoaded("journeymap")
                || loader.isModLoaded("map_atlases");
    }

    public String getActiveIntegrationsLabel() {
        if (integrations.isEmpty()) {
            List<String> detected = new ArrayList<>();
            FabricLoader loader = FabricLoader.getInstance();
            if (loader.isModLoaded("xaerominimap") || loader.isModLoaded("xaerominimapfair")) {
                detected.add("Xaero's Minimap");
            }
            if (loader.isModLoaded("xaeroworldmap")) {
                detected.add("Xaero's World Map");
            }
            if (loader.isModLoaded("journeymap")) {
                detected.add("JourneyMap");
            }
            if (loader.isModLoaded("map_atlases")) {
                detected.add("Map Atlases");
            }
            return detected.isEmpty() ? "None" : String.join(", ", detected);
        }
        return integrations.stream()
                .map(MapIntegration::getDisplayName)
                .collect(Collectors.joining(", "));
    }

    /**
     * Synchronizes waypoints across every installed map mod for the given search results.
     * Automatically avoids duplicates and removes stale markers from previous searches.
     */
    public synchronized void applySearchResults(List<SearchResult> results) {
        if (!hasSupportedMapMod()) {
            return;
        }

        if (results == null || results.isEmpty()) {
            clearActiveWaypoints();
            return;
        }

        this.activeSearchItemId = results.get(0).getMatchedItemId();
        this.activeSearchDisplayName = results.get(0).getMatchedItemDisplayName();

        Set<String> nextIds = new LinkedHashSet<>();
        for (SearchResult result : results) {
            ContainerRecord container = result.getContainer();
            String id = ChestWaypoint.buildId(container);
            nextIds.add(id);

            ChestWaypoint waypoint = new ChestWaypoint(
                    id,
                    result.getMatchedItemDisplayName() + " x" + result.getQuantity(),
                    result.getMatchedItemId(),
                    result.getMatchedItemDisplayName(),
                    result.getQuantity(),
                    container.toBlockPos(),
                    container.getDimension(),
                    container.getContainerType(),
                    result.isRecentlyVerified()
            );

            activeWaypoints.put(id, waypoint);
            for (MapIntegration integration : integrations) {
                integration.upsertWaypoint(waypoint);
            }
        }

        // Remove any previously active waypoints that no longer match this search
        List<String> staleIds = activeWaypoints.keySet().stream()
                .filter(id -> !nextIds.contains(id))
                .toList();
        for (String staleId : staleIds) {
            ChestWaypoint removed = activeWaypoints.remove(staleId);
            if (removed != null) {
                for (MapIntegration integration : integrations) {
                    integration.removeWaypoint(staleId, removed.dimension());
                }
            }
        }
    }

    /**
     * Called by {@link com.chestfinder.scanner.StorageScanner} whenever a container record
     * changes on revisit. Keeps active search waypoints accurate in real time.
     */
    public synchronized void onContainerUpdated(ContainerRecord updatedRecord) {
        if (!hasSupportedMapMod() || activeSearchItemId == null || updatedRecord == null) {
            return;
        }

        String id = ChestWaypoint.buildId(updatedRecord);
        int newCount = updatedRecord.getItemCount(activeSearchItemId);

        if (newCount > 0) {
            ChestWaypoint updatedWaypoint = new ChestWaypoint(
                    id,
                    activeSearchDisplayName + " x" + newCount,
                    activeSearchItemId,
                    activeSearchDisplayName,
                    newCount,
                    updatedRecord.toBlockPos(),
                    updatedRecord.getDimension(),
                    updatedRecord.getContainerType(),
                    true
            );
            activeWaypoints.put(id, updatedWaypoint);
            for (MapIntegration integration : integrations) {
                integration.upsertWaypoint(updatedWaypoint);
            }
        } else if (activeWaypoints.containsKey(id)) {
            activeWaypoints.remove(id);
            for (MapIntegration integration : integrations) {
                integration.removeWaypoint(id, updatedRecord.getDimension());
            }
        }
    }

    public synchronized void clearActiveWaypoints() {
        for (MapIntegration integration : integrations) {
            integration.clearAllManagedWaypoints();
        }
        activeWaypoints.clear();
        activeSearchItemId = null;
        activeSearchDisplayName = null;
    }

    public int getActiveWaypointCount() {
        return activeWaypoints.size();
    }
}
